class Booleans:
    @staticmethod
    def true() -> bool:
        return True

    @staticmethod
    def false() -> bool:
        return False